from flask import Blueprint, send_file
from app.services.report_service import generate_analysis_report

report_bp = Blueprint('report', __name__)

@report_bp.route('/report/<int:analysis_id>', methods=['GET'])
def download_report(analysis_id):
    analysis = Analysis.query.get(analysis_id)
    if not analysis:
        return {"error": "Análise não encontrada"}, 404

    buffer = generate_analysis_report({
        "created_at": analysis.created_at,
        "topics": analysis.topics,
        "suggestions": analysis.suggestions
    })
    return send_file(buffer, as_attachment=True, download_name=f"report_{analysis_id}.pdf", mimetype="application/pdf")