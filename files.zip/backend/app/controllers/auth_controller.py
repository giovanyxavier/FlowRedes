from flask import Blueprint, request, jsonify
from app.services.auth_service import authenticate_user, register_user

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    token = authenticate_user(data['email'], data['password'])
    if token:
        return jsonify({"token": token}), 200
    return jsonify({"error": "Invalid credentials"}), 401

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    user = register_user(data['email'], data['password'])
    return jsonify({"message": "User registered successfully"}), 201