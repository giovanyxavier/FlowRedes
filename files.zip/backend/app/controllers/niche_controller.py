from flask import request

@niche_bp.route('/user/analyses', methods=['GET'])
def get_analyses():
    user_id = request.args.get('user_id')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    query = Analysis.query.filter_by(user_id=user_id)
    if start_date:
        query = query.filter(Analysis.created_at >= start_date)
    if end_date:
        query = query.filter(Analysis.created_at <= end_date)

    analyses = query.all()
    return jsonify([{
        "id": analysis.id,
        "created_at": analysis.created_at,
        "topics": analysis.topics,
        "suggestions": analysis.suggestions,
    } for analysis in analyses])