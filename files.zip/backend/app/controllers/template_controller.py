from flask import Blueprint, request, jsonify
from app.models.post_template import PostTemplate
from app import db

template_bp = Blueprint('template', __name__)

@template_bp.route('/templates', methods=['GET'])
def get_templates():
    user_id = request.args.get('user_id')
    templates = PostTemplate.query.filter_by(user_id=user_id).all()
    return jsonify([{"id": t.id, "title": t.title, "content": t.content} for t in templates])

@template_bp.route('/templates', methods=['POST'])
def create_template():
    data = request.json
    template = PostTemplate(title=data['title'], content=data['content'], user_id=data['user_id'])
    db.session.add(template)
    db.session.commit()
    return jsonify({"message": "Template criado com sucesso."}), 201

@template_bp.route('/templates/<int:template_id>', methods=['DELETE'])
def delete_template(template_id):
    template = PostTemplate.query.get(template_id)
    if template:
        db.session.delete(template)
        db.session.commit()
        return jsonify({"message": "Template excluído com sucesso."})
    return jsonify({"error": "Template não encontrado."}), 404