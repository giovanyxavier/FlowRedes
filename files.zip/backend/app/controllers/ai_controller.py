from flask import Blueprint, request, jsonify
from app.services.ai_template_suggestions import suggest_post_templates

ai_bp = Blueprint('ai', __name__)

@ai_bp.route('/ai/suggest-templates', methods=['POST'])
def get_template_suggestions():
    data = request.json
    topics = data.get('topics', [])
    if not topics:
        return jsonify({"error": "Tópicos são obrigatórios."}), 400

    suggestions = suggest_post_templates(topics)
    return jsonify({"suggestions": suggestions})