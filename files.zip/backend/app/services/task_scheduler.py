from apscheduler.schedulers.background import BackgroundScheduler
from app.services.niche_analysis_service import analyze_niche_and_suggest
from app.models.user import User
from app.models.post import Post
from app.utils.email import send_email_notification

scheduler = BackgroundScheduler()

def schedule_automatic_analysis():
    @scheduler.scheduled_job('interval', hours=24)  # Executa a cada 24 horas
    def daily_analysis():
        users = User.query.all()
        for user in users:
            posts = Post.query.filter_by(user_id=user.id).all()
            hashtags = set([hashtag for post in posts for hashtag in post.hashtags])
            result = analyze_niche_and_suggest(posts, hashtags)
            # Salva o resultado no banco de dados
            user.last_analysis = result
            user.save()
            # Envia notificação por email
            send_email_notification(
                user.email,
                "Resultados da Análise de Nicho",
                f"Tópicos Relevantes: {result['topics']}\nSugestões de Novos Posts: {result['suggestions']}"
            )

    scheduler.start()