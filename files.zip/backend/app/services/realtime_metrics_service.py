from flask_socketio import emit
from app.services.metrics_service import fetch_post_metrics
import time
import threading

def start_realtime_metrics(socketio, posts, interval=30):
    """
    Atualiza métricas dos posts em tempo real e envia via WebSocket.
    :param socketio: Instância do SocketIO.
    :param posts: Lista de posts a ser monitorada.
    :param interval: Intervalo entre atualizações (em segundos).
    """
    def update_metrics():
        while True:
            for post in posts:
                metrics = fetch_post_metrics(post['api_url'], post['access_token'], post['post_id'])
                if metrics:
                    socketio.emit('update_metrics', {"post_id": post['post_id'], "metrics": metrics})
            time.sleep(interval)

    thread = threading.Thread(target=update_metrics)
    thread.daemon = True
    thread.start()