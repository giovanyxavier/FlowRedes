from reportlab.pdfgen import canvas
from io import BytesIO

def generate_analysis_report(analysis):
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer)
    pdf.setTitle("Relatório de Análise")

    pdf.drawString(100, 800, "Relatório de Análise de Nicho")
    pdf.drawString(100, 780, f"Data: {analysis['created_at']}")
    pdf.drawString(100, 760, f"Tópicos: {analysis['topics']}")
    pdf.drawString(100, 740, f"Sugestões: {analysis['suggestions']}")

    pdf.save()
    buffer.seek(0)
    return buffer