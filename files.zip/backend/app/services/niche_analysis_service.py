from transformers import pipeline
from collections import Counter
import openai

# Configuração da API OpenAI
openai.api_key = "YOUR_OPENAI_API_KEY"

# Função para analisar tópicos do nicho
def analyze_topics(posts):
    nlp = pipeline("summarization")
    all_text = " ".join([post['content'] for post in posts])
    summary = nlp(all_text, max_length=50, min_length=5, do_sample=False)
    return summary[0]['summary_text']

# Função para sugerir novas ideias de conteúdo
def suggest_new_posts(posts, hashtags):
    prompt = f"""
    Baseado nos seguintes posts e hashtags:
    Posts: {posts}
    Hashtags: {hashtags}
    Sugira 5 ideias criativas de novos posts para redes sociais, com tópicos e hashtags relevantes.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "Você é um especialista em marketing digital."},
                  {"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

# Função principal para análise e sugestões
def analyze_niche_and_suggest(posts, hashtags):
    topics = analyze_topics(posts)
    suggestions = suggest_new_posts(posts, hashtags)
    return {
        "topics": topics,
        "suggestions": suggestions
    }