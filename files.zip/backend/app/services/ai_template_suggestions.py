import openai

# Configure sua chave da API OpenAI
openai.api_key = "YOUR_OPENAI_API_KEY"

def suggest_post_templates(topics):
    """
    Gera sugestões de modelos de postagem com base nos tópicos fornecidos.
    :param topics: Lista de tópicos relevantes.
    :return: Lista de sugestões de modelos.
    """
    prompt = f"""
    Baseado nos seguintes tópicos de interesse: {', '.join(topics)},
    sugira 5 ideias criativas de modelos de postagem para redes sociais. Cada modelo deve incluir:
    - Um título atraente
    - Um conteúdo básico (máximo de 200 caracteres)
    - Uma hashtag relevante
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "Você é um especialista em marketing digital."},
                  {"role": "user", "content": prompt}]
    )
    suggestions = response['choices'][0]['message']['content']
    return suggestions.split("\n")