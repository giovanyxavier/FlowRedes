from app.utils.redis_client import cache_data, get_cached_data

def fetch_post_metrics(api_url, access_token, post_id):
    cache_key = f"metrics:{post_id}"
    cached_metrics = get_cached_data(cache_key)
    if cached_metrics:
        return cached_metrics

    # Consulta a API se o dado não estiver no cache
    url = f"{api_url}/{post_id}/insights"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        metrics = response.json()
        cache_data(cache_key, metrics)  # Armazena no cache
        return metrics
    return None