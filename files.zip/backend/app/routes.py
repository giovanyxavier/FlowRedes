from flask_socketio import emit

def setup_routes(app, socketio):
    @app.route("/")
    def home():
        return {"message": "Bem-vindo ao SocialFlow!"}

    @socketio.on("connect")
    def handle_connect():
        emit("notification", {"message": "Conectado ao servidor!"})