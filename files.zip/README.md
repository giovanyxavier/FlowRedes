# SocialFlow

Uma plataforma para agendamento e análise de posts em redes sociais.

## Funcionalidades
- Conexão com redes sociais
- Agendamento de posts
- Análise de métricas

## Como Rodar
1. Clone o repositório.
2. Execute `docker-compose up` para iniciar os serviços.
3. Acesse o frontend em `http://localhost:3000` e o backend em `http://localhost:5000`.