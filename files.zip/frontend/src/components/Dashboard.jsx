import React from "react";
import NicheAnalysis from "./NicheAnalysis";
import AnalysisHistory from "./AnalysisHistory";

function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <NicheAnalysis />
      <AnalysisHistory />
    </div>
  );
}

export default Dashboard;