import React, { useEffect, useState } from "react";
import socket from "../api/websocket";

function RealtimeMetrics({ postId }) {
  const [metrics, setMetrics] = useState(null);

  useEffect(() => {
    socket.on("update_metrics", (data) => {
      if (data.post_id === postId) {
        setMetrics(data.metrics);
      }
    });

    return () => {
      socket.off("update_metrics");
    };
  }, [postId]);

  return (
    <div>
      <h3>Métricas em Tempo Real</h3>
      {metrics ? (
        <ul>
          <li>Curtidas: {metrics.likes}</li>
          <li>Comentários: {metrics.comments}</li>
          <li>Compartilhamentos: {metrics.shares}</li>
        </ul>
      ) : (
        <p>Carregando métricas...</p>
      )}
    </div>
  );
}

export default RealtimeMetrics;