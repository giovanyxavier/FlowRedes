import React, { useState } from "react";
import axios from "../api";

function NicheAnalysis() {
  const [posts, setPosts] = useState([]);
  const [hashtags, setHashtags] = useState([]);
  const [analysis, setAnalysis] = useState(null);

  const handleAnalyze = async () => {
    try {
      const response = await axios.post("/analyze", { posts, hashtags });
      setAnalysis(response.data);
    } catch (err) {
      console.error("Erro ao realizar análise:", err);
    }
  };

  return (
    <div className="p-5">
      <h2 className="text-xl font-bold">Análise do Nicho</h2>
      <textarea
        placeholder="Adicione os posts (separados por linha)"
        value={posts.join("\n")}
        onChange={(e) => setPosts(e.target.value.split("\n"))}
        className="w-full p-2 border mt-2"
      />
      <input
        type="text"
        placeholder="Hashtags separadas por vírgula"
        value={hashtags.join(",")}
        onChange={(e) => setHashtags(e.target.value.split(","))}
        className="w-full p-2 border mt-2"
      />
      <button onClick={handleAnalyze} className="bg-blue-500 text-white p-2 mt-4 rounded">
        Analisar
      </button>
      {analysis && (
        <div className="mt-4">
          <h3 className="text-lg font-bold">Tópicos Relevantes:</h3>
          <p>{analysis.topics}</p>
          <h3 className="text-lg font-bold mt-4">Sugestões de Novos Posts:</h3>
          <ul>
            {analysis.suggestions.split("\n").map((suggestion, idx) => (
              <li key={idx} className="mt-2">
                - {suggestion}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default NicheAnalysis;