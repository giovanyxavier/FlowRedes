import React, { useState, useEffect } from "react";
import axios from "../api";

function TemplateLibrary({ userId, onApplyTemplate }) {
  const [templates, setTemplates] = useState([]);
  const [newTemplate, setNewTemplate] = useState({ title: "", content: "" });

  useEffect(() => {
    const fetchTemplates = async () => {
      const response = await axios.get(`/templates?user_id=${userId}`);
      setTemplates(response.data);
    };
    fetchTemplates();
  }, [userId]);

  const handleCreateTemplate = async () => {
    if (newTemplate.title && newTemplate.content) {
      await axios.post("/templates", { ...newTemplate, user_id: userId });
      setNewTemplate({ title: "", content: "" });
      const response = await axios.get(`/templates?user_id=${userId}`);
      setTemplates(response.data);
    }
  };

  const handleDeleteTemplate = async (id) => {
    await axios.delete(`/templates/${id}`);
    const response = await axios.get(`/templates?user_id=${userId}`);
    setTemplates(response.data);
  };

  return (
    <div>
      <h2>Biblioteca de Modelos</h2>
      <div>
        <input
          type="text"
          placeholder="Título do modelo"
          value={newTemplate.title}
          onChange={(e) => setNewTemplate({ ...newTemplate, title: e.target.value })}
        />
        <textarea
          placeholder="Conteúdo do modelo"
          value={newTemplate.content}
          onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
        />
        <button onClick={handleCreateTemplate}>Criar Modelo</button>
      </div>
      <ul>
        {templates.map((template) => (
          <li key={template.id}>
            <h3>{template.title}</h3>
            <p>{template.content}</p>
            <button onClick={() => onApplyTemplate(template)}>Aplicar</button>
            <button onClick={() => handleDeleteTemplate(template.id)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TemplateLibrary;