import React from "react";

function AnalysisHistory({ analyses }) {
  const downloadReport = (analysisId) => {
    window.open(`/api/report/${analysisId}`, "_blank");
  };

  return (
    <ul>
      {analyses.map((analysis, index) => (
        <li key={index}>
          <h3>Análise de {new Date(analysis.created_at).toLocaleDateString()}</h3>
          <p><strong>Tópicos:</strong> {analysis.topics}</p>
          <p><strong>Sugestões:</strong> {analysis.suggestions}</p>
          <button onClick={() => downloadReport(analysis.id)}>Baixar Relatório</button>
        </li>
      ))}
    </ul>
  );
}

export default AnalysisHistory;