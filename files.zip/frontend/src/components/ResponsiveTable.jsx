import React from "react";

function ResponsiveTable({ data }) {
  return (
    <div className="overflow-x-auto">
      <table className="table-auto w-full border-collapse border border-gray-500">
        <thead>
          <tr>
            <th className="border border-gray-400 px-4 py-2">Título</th>
            <th className="border border-gray-400 px-4 py-2">Conteúdo</th>
            <th className="border border-gray-400 px-4 py-2">Ações</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, idx) => (
            <tr key={idx} className="text-center">
              <td className="border border-gray-400 px-4 py-2">{item.title}</td>
              <td className="border border-gray-400 px-4 py-2">{item.content}</td>
              <td className="border border-gray-400 px-4 py-2">
                <button className="bg-blue-500 text-white px-2 py-1 rounded">Editar</button>
                <button className="bg-red-500 text-white px-2 py-1 ml-2 rounded">Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ResponsiveTable;