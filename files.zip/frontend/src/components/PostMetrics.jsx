import React, { useEffect, useState } from "react";
import axios from "../api";

function PostMetrics({ postId }) {
  const [metrics, setMetrics] = useState(null);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await axios.get(`/posts/${postId}/metrics`);
        setMetrics(response.data);
      } catch (err) {
        console.error("Erro ao buscar métricas:", err);
      }
    };
    fetchMetrics();
  }, [postId]);

  return (
    <div>
      <h3>Métricas do Post</h3>
      {metrics ? (
        <ul>
          <li>Curtidas: {metrics.likes}</li>
          <li>Comentários: {metrics.comments}</li>
          <li>Compartilhamentos: {metrics.shares}</li>
        </ul>
      ) : (
        <p>Carregando métricas...</p>
      )}
    </div>
  );
}

export default PostMetrics;