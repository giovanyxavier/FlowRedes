import React, { useState } from "react";
import axios from "../api";

function AISuggestions({ onApplySuggestion }) {
  const [topics, setTopics] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  const handleGetSuggestions = async () => {
    try {
      const response = await axios.post("/ai/suggest-templates", { topics: topics.split(",") });
      setSuggestions(response.data.suggestions);
    } catch (err) {
      console.error("Erro ao obter sugestões de IA:", err);
    }
  };

  return (
    <div>
      <h2>Sugestões de IA para Modelos</h2>
      <input
        type="text"
        placeholder="Insira tópicos separados por vírgula..."
        value={topics}
        onChange={(e) => setTopics(e.target.value)}
        className="w-full p-2 border mt-2"
      />
      <button onClick={handleGetSuggestions} className="bg-blue-500 text-white p-2 mt-4 rounded">
        Obter Sugestões
      </button>
      <ul>
        {suggestions.map((suggestion, idx) => (
          <li key={idx} className="mt-2">
            <p>{suggestion}</p>
            <button
              onClick={() => onApplySuggestion(suggestion)}
              className="bg-green-500 text-white p-2 mt-2 rounded"
            >
              Aplicar
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AISuggestions;