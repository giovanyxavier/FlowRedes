import React, { useEffect } from "react";
import socket from "./api/websocket";

function App() {
  useEffect(() => {
    socket.on("notification", (data) => {
      alert(`Nova notificação: ${data.message}`);
    });
  }, []);

  return (
    <div>
      <h1>SocialFlow</h1>
    </div>
  );
}

export default App;